Voici quelques informations concernant le mini-projet de Java que j'ai développer. 
Le mini-projet que j'ai choisit de traiter est un pong.
Le but de ce projet était de développer le jeu Pong qui sera jouable aussi bien sur la consol Java que dans une fenêtre graphique.
Au terme de ce projet, nous pouvons donc joueur au Pong à 1 ou 2 joueurs (sur le même ordinateur) avec ou sans interface graphique.

Dans la version console, j'ai été contraint de devoir créer un fenêtre graphique car la commande qui permet d'écouter les entrée claviers 
lorsqu'elles sont pressés est liées à la classe JPanel. Donc lors du fontionnement du jeu dans la console, une fenêtre s'ouvrira et 
écoutera les entrées claviers. 
Pour afficher le rendu en mode console j'ai utilisé un tableau de tableau de charactère, il faut donc que la console soit assez grande 
pour pouvoir afficher toute la scène. 

Le mode 2 joueurs est fonctionnel mais nécessite d'avoir un clavier avec pavé numérique pour pouvoir faire bouger le second joueur.
Si il n'y a qu'un joueur, une IA va jouer le rôle du second joueur.

