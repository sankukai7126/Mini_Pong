import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;
import javax.swing.JFrame;

public class Consol{

	static int ballX = 9;
	static int ballY = 4;
	
	public static int player1X = 0;
	public static int player1Y = 2;
	public static int player1S = 4;
	
	public static int player2X = 19;
	public static int player2Y = 2;
	public static int player2S = 4;
	
	public static int Xspeed = 1;
	public static int Yspeed = 1;
	
	int scorePlayer1 = 0;
	int scorePlayer2 = 0;
	
	char[][] screen; 
	
	public static boolean twoPlayer = false;
	
	JFrame test;
	
	
	private Consol_Input consInp = new Consol_Input();
	
	
	public Consol(boolean TwoPlayers) {
		screen = new char[20][10];
		
		this.twoPlayer = TwoPlayers;
		
		test  = new JFrame();
		test.setVisible(true);
		test.addKeyListener(consInp);
		test.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		for(int j = 0; j<10; j++) {
			for(int i = 0; i<20; i++) {
				if(j >= player2Y && j<player2Y + player2S && i == player2X) {
					screen[i][j] = '|';
				}else if(j >= player1Y && j<player1Y + player1S && i == player1X) {
					screen[i][j] = '|';
				}else if(i == ballX && j == ballY){
					screen[i][j] = 'O';
				}else {
					screen[i][j] = ' ';
				}
			}
		}
		
		for(int j = 0; j<10; j++) {
			for(int i = 0; i<20; i++) {
				System.out.print(screen[i][j]);
				if(i==19) {
					System.out.print('\n');
				}
			}
		}
		
		go();
		
		
	}
	
	public static void wait(int ms) {
		try
        {
            Thread.sleep(ms);
        }
        catch(InterruptedException ex)
        {
            Thread.currentThread().interrupt();
        }
	}

	void go() {
		for(;;) {
			ballX += Xspeed;
			ballY += Yspeed;
			
			for(int j = 0; j<10; j++) {
				for(int i = 0; i<20; i++) {
					if(i == ballX && j == ballY){
						screen[i][j] = 'O';
					}else if(i == player2X) {
						if(j >= player2Y && j<player2Y + player2S ) {
							screen[i][j] = '|';
						}else {
							screen[i][j] = 'x';
						}
					}else if(i == player1X) {
						if(j >= player1Y && j<player1Y + player1S) {
							screen[i][j] = '|';
						}else {
							screen[i][j] = 'x';
						}
					}else {
						screen[i][j] = ' ';
					}
				}
			}
			
			if(ballY <= 0) {
				Yspeed = Yspeed * (-1);
			}else if(ballY >= 9) {
				Yspeed = Yspeed * (-1);
			}
			
			if(ballX >= player2X) {
				if(ballY >= player2Y && ballY<= player2S) {
					Xspeed = -1;
				}else {
					scorePlayer1 ++;
					ballX = 9;
					ballY = 4;
				}
			}else if(ballX <= 0) {
				if(ballY >= player1Y && ballY<= player1S) {
					Xspeed = 1;
				}else {
					scorePlayer2 ++;
					ballX = 9;
					ballY = 4;
				}
			}
			
			if(twoPlayer == false) {
				if(ballY>=player2Y+player2S && player2Y+player2S <= 9) {
					player2Y ++;
				}else if(ballY<=player2Y && player2Y > 0) {
					player2Y --;
				}
			}
			
			
			for(int j = 0; j<10; j++) {
				for(int i = 0; i<20; i++) {
					System.out.print(screen[i][j]);
					if(i==19) {
						System.out.print('\n');
					}
				}
			}
			
			System.out.println("        " + scorePlayer1 + " : " + scorePlayer2);
			System.out.print('\n');
			System.out.print('\n');
			System.out.print('\n');
			
			wait(2000);
			
		}
		
	}
	
}
