import java.util.Scanner;
public class Main {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Pong");
		int player2 = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("2 Joueurs? (Entrer un si oui, 0 si non)");
		player2 = sc.nextInt();
		
		int graph = 0;
		Scanner sc_graph = new Scanner(System.in);
		System.out.println("Jouer sur une interface graphique? (Entrer un si oui, 0 si non)");
		graph = sc_graph.nextInt();
		
		
		if(graph == 1) {
			if(player2 == 1) {
				Fenetre fenetre = new Fenetre(true);
			}else {
				Fenetre fenetre = new Fenetre(false);
			}
		}else {
			if(player2 == 1) {
				Consol consol = new Consol(true);
			}else {
				Consol consol = new Consol(false);
			}
		}
		
		
		
	}
	

}
